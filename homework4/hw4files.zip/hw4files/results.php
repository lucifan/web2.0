<!DOCTYPE html>
<html>
	<head>
		<title>NerdLuv</title>
		<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
		<link href="heart.gif" type="image/gif" rel="shortcut icon" />
		<link href="nerdluv.css" type="text/css" rel="stylesheet" />
	</head>

	<body>
		<div id="main">
			<div id="bannerarea">
				<img src="nerdluv.png" alt="banner logo" /> <br />
				where meek geeks meet
			</div>
	
			<div id="matches">
				<h1>Matches for Marty Stepp</h1>

				<div class="match">
					<p class="name">
						<img src="images/ada_lovelace.jpg" alt="Ada Lovelace" />
						Ada Lovelace 
					</p>

					<p class="info">
						<strong>gender:</strong>  F <br />
						<strong>age:</strong>     96 <br />
						<strong>type:</strong>    ISTJ <br />
						<strong>OS:</strong>      Linux <br />
						<strong>rating:</strong>  4
					</p>
				</div>
			</div>
		</div>
		
		<p>
			Results and page (C) Copyright 2009 NerdLuv Inc.
		</p>

		<div id="w3c">
			<a href="http://validator.w3.org/check/referer">
				<img src="http://www.w3.org/Icons/valid-xhtml11" alt="Valid XHTML 1.1" /></a>
			<a href="http://jigsaw.w3.org/css-validator/check/referer">
				<img src="http://jigsaw.w3.org/css-validator/images/vcss" alt="Valid CSS" /></a>
		</div>
	</body>
</html>
